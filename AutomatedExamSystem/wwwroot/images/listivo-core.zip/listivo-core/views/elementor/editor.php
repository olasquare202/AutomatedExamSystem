<lst-elementor-editor id="tdf-templates-manager">
    <div slot-scope="props"></div>
</lst-elementor-editor>