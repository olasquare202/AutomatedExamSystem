<?php
/* @var \Tangibledesign\Framework\Models\Payments\UserSubscription $userSubscription */
/* @var \Tangibledesign\Framework\Core\Collection $subscriptions */
/* @var array $users */
/* @var string $message */
/* @var string $messageType */
?>

<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php esc_html_e('Edit User Subscription', 'listivo-core'); ?>
        <small>(ID: <?php echo esc_html($userSubscription->getId()); ?>)</small>
    </h1>
    
    <a href="<?php echo esc_url(admin_url('admin.php?page=listivo_monetization&tab=user_subscriptions')); ?>" 
       class="page-title-action">
        ← <?php esc_html_e('Back to List', 'listivo-core'); ?>
    </a>

    <?php if (!empty($message)) : ?>
        <div class="notice notice-<?php echo esc_attr($messageType === 'success' ? 'success' : 'error'); ?> is-dismissible">
            <p><?php echo esc_html($message); ?></p>
        </div>
    <?php endif; ?>

    <div class="listivo-backend-content tdf-app">
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php?action=tdf/userSubscription/save')); ?>">
            <?php wp_nonce_field('save_user_subscription_meta'); ?>
            <input type="hidden" name="user_subscription_id" value="<?php echo esc_attr($userSubscription->getId()); ?>">

            <!-- Main Data Section -->
            <div class="postbox">
                <h2 class="hndle"><?php esc_html_e('Subscription Data', 'listivo-core'); ?></h2>
                <div class="inside">
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row">
                                    <?php esc_html_e('User', 'listivo-core'); ?>
                                </th>
                                <td>
                                    <?php 
                                    $user = $userSubscription->getUser();
                                    if ($user) : ?>
                                        <strong><?php echo esc_html($user->getDisplayName()); ?></strong><br>
                                        <?php echo esc_html($user->getMail()); ?>
                                    <?php else : ?>
                                        <em><?php esc_html_e('User not found', 'listivo-core'); ?></em>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row">
                                    <?php esc_html_e('Subscription', 'listivo-core'); ?>
                                </th>
                                <td>
                                    <?php 
                                    $subscription = $userSubscription->getSubscription();
                                    if ($subscription) : ?>
                                        <strong><?php echo esc_html($subscription->getName()); ?></strong>
                                    <?php else : ?>
                                        <em><?php esc_html_e('Subscription not found', 'listivo-core'); ?></em>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <th scope="row">
                                    <?php esc_html_e('Status', 'listivo-core'); ?>
                                </th>
                                <td>
                                    <span class="button button-small" style="cursor: default; background: <?php 
                                        echo $userSubscription->getStatus() === 'active' ? '#46b450' : 
                                             ($userSubscription->getStatus() === 'canceled' ? '#dc3232' : '#ffb900'); 
                                    ?>; color: white;">
                                        <?php echo esc_html($userSubscription->getStatusLabel()); ?>
                                    </span>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row">
                                    <?php esc_html_e('Payment Method', 'listivo-core'); ?>
                                </th>
                                <td>
                                    <?php 
                                    $method = $userSubscription->getMeta('method');
                                    echo esc_html(ucfirst($method ?: 'Unknown')); 
                                    ?>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row">
                                    <?php esc_html_e('Created', 'listivo-core'); ?>
                                </th>
                                <td>
                                    <?php echo esc_html(get_the_date('Y-m-d H:i:s', $userSubscription->getId())); ?>
                                </td>
                            </tr>

                            <tr>
                                <th scope="row">
                                    <?php esc_html_e('Modified', 'listivo-core'); ?>
                                </th>
                                <td>
                                    <?php echo esc_html(get_the_modified_date('Y-m-d H:i:s', $userSubscription->getId())); ?>
                                </td>
                            </tr>

                            <?php $stripeSessionId = $userSubscription->getMeta('stripe_session_id'); ?>
                            <?php if (!empty($stripeSessionId)) : ?>
                                <tr>
                                    <th scope="row">
                                        <?php esc_html_e('Stripe Session', 'listivo-core'); ?>
                                    </th>
                                    <td>
                                        <code style="font-size: 11px; word-break: break-all;"><?php echo esc_html($stripeSessionId); ?></code>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Stripe Data Section -->
            <div class="postbox">
                <h2 class="hndle"><?php esc_html_e('Stripe Data', 'listivo-core'); ?></h2>
                <div class="inside">
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row">
                                    <label for="stripe_subscription_id"><?php esc_html_e('Stripe Subscription ID', 'listivo-core'); ?></label>
                                </th>
                                <td>
                                    <input type="text" 
                                           name="stripe_subscription_id" 
                                           id="stripe_subscription_id" 
                                           value="<?php echo esc_attr($userSubscription->getMeta('stripe_subscription_id')); ?>" 
                                           class="regular-text" />
                                    <p class="description"><?php esc_html_e('Stripe subscription ID (e.g., sub_1234567890)', 'listivo-core'); ?></p>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row">
                                    <label for="stripe_customer_id"><?php esc_html_e('Stripe Customer ID', 'listivo-core'); ?></label>
                                </th>
                                <td>
                                    <input type="text" 
                                           name="stripe_customer_id" 
                                           id="stripe_customer_id" 
                                           value="<?php echo esc_attr($userSubscription->getMeta('stripe_customer_id')); ?>" 
                                           class="regular-text" />
                                    <p class="description"><?php esc_html_e('Stripe customer ID (e.g., cus_1234567890)', 'listivo-core'); ?></p>
                                </td>
                            </tr>

                            <tr>
                                <th scope="row">
                                    <label for="current_period_start"><?php esc_html_e('Current Period Start', 'listivo-core'); ?></label>
                                </th>
                                <td>
                                    <?php 
                                    $periodStart = $userSubscription->getCurrentPeriodStart();
                                    $periodStartValue = $periodStart ? $periodStart->format('Y-m-d H:i:s') : '';
                                    ?>
                                    <input type="datetime-local" 
                                           name="current_period_start" 
                                           id="current_period_start" 
                                           value="<?php echo esc_attr(str_replace(' ', 'T', $periodStartValue)); ?>" 
                                           class="regular-text" />
                                </td>
                            </tr>

                            <tr>
                                <th scope="row">
                                    <label for="current_period_end"><?php esc_html_e('Current Period End', 'listivo-core'); ?></label>
                                </th>
                                <td>
                                    <?php 
                                    $periodEnd = $userSubscription->getCurrentPeriodEnd();
                                    $periodEndValue = $periodEnd ? $periodEnd->format('Y-m-d H:i:s') : '';
                                    ?>
                                    <input type="datetime-local" 
                                           name="current_period_end" 
                                           id="current_period_end" 
                                           value="<?php echo esc_attr(str_replace(' ', 'T', $periodEndValue)); ?>" 
                                           class="regular-text" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Actions Section -->
            <div class="postbox">
                <h2 class="hndle"><?php esc_html_e('Actions', 'listivo-core'); ?></h2>
                <div class="inside">
                    <p>
                        <input type="submit" 
                               name="save" 
                               class="button button-primary" 
                               value="<?php esc_attr_e('Update Subscription', 'listivo-core'); ?>" />

                        <?php if (!$userSubscription->isFree() && !empty($userSubscription->getMeta('stripe_subscription_id'))) : ?>
                            <lst-sync-user-subscription
                                    request-url="<?php echo esc_url(tdf_action_url('tdf/userSubscription/sync')); ?>"
                                    :user-subscription-id="<?php echo esc_attr($userSubscription->getId()); ?>"
                                    style="display: inline-block; margin-left: 10px;"
                            >
                                <button
                                        class="button button-secondary"
                                        slot-scope="syncUserSubscription"
                                        @click.stop.prevent="syncUserSubscription.onSync"
                                        type="button"
                                >
                                    <?php esc_html_e('Sync from Stripe', 'listivo-core'); ?>
                                </button>
                            </lst-sync-user-subscription>
                        <?php endif; ?>

                        <a href="<?php echo esc_url(admin_url('admin.php?page=listivo_monetization&tab=user_subscriptions')); ?>" 
                           class="button button-secondary" 
                           style="margin-left: 10px;">
                            <?php esc_html_e('Back to List', 'listivo-core'); ?>
                        </a>
                    </p>
                </div>
            </div>
        </form>
    </div>
</div>