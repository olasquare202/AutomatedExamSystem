<?php

require 'vendor/autoload.php';

require 'functions.php';