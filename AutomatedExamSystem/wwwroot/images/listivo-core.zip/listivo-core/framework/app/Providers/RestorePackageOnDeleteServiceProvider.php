<?php

namespace Tangibledesign\Framework\Providers;

use Tangibledesign\Framework\Core\ServiceProvider;
use Tangibledesign\Framework\Models\Model;
use WP_Post;

/**
 * Restores pending packages when unpublished listings are deleted.
 * This prevents users from losing their purchased packages when deleting draft/pending listings.
 */
class RestorePackageOnDeleteServiceProvider extends ServiceProvider
{
    /**
     * Register the hook with priority 5 to run before image deletion (priority 10)
     */
    public function afterInitiation(): void
    {
        add_action('before_delete_post', [$this, 'restorePackageBeforeDelete'], 5, 2);
    }

    /**
     * Restore package to user if deleting an unpublished listing with pending package
     * 
     * @param int $postId
     * @param WP_Post $post
     */
    public function restorePackageBeforeDelete($postId, WP_Post $post): void
    {
        // Only process model post types
        if ($post->post_type !== tdf_model_post_type()) {
            return;
        }

        // Only process if payments are enabled
        if (!tdf_settings()->paymentsEnabled()) {
            return;
        }

        // Create model instance
        $model = tdf_post_factory()->create($postId);
        if (!$model instanceof Model) {
            return;
        }

        // Only restore packages for unpublished listings (draft, pending)
        // Published listings have already consumed their package value
        if ($model->isPublished()) {
            return;
        }

        // Check if model has pending package
        if (!$model->hasPendingPackage()) {
            return;
        }

        // Get the pending package and user
        $package = $model->getPendingPackage();
        $user = $model->getUser();
        
        // Restore the package to user's balance
        if ($package && $user) {
            $user->increasePackage($package->getId());
            
            // Log the restoration for debugging purposes
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log(sprintf(
                    'Restored package #%d to user #%d when deleting unpublished listing #%d',
                    $package->getId(),
                    $user->getId(),
                    $model->getId()
                ));
            }
        }

        // Remove pending package metadata from the listing
        $model->removePendingPackage();
    }
}