<?php


namespace Tangibledesign\Framework\Queries;


/**
 * Class QueryMenus
 * @package Tangibledesign\Framework\Queries
 */
class QueryMenus extends QueryTerms
{
    /** @var string */
    protected string $taxonomy = 'nav_menu';

}