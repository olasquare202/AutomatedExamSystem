<?php


namespace Tangibledesign\Framework\Queries;


/**
 * Class QueryPages
 * @package Tangibledesign\Framework\Queries
 */
class QueryPages extends QueryPosts
{
    /**
     * @var string
     */
    protected string $postType = 'page';

}