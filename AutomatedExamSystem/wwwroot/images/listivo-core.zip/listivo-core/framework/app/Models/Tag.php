<?php


namespace Tangibledesign\Framework\Models;


use Tangibledesign\Framework\Models\Term\Term;

/**
 * Class Tag
 * @package Tangibledesign\Framework\Models
 */
class Tag extends Term
{

}