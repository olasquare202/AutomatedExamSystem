<?php


namespace Tangibledesign\Framework\Models;


use Tangibledesign\Framework\Models\Post\Post;

/**
 * Class ContactForm
 * @package Tangibledesign\Framework\Models
 */
class ContactForm extends Post
{
    public const POST_TYPE = 'wpcf7_contact_form';


}