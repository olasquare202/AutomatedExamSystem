<?php


namespace Tangibledesign\Framework\Helpers;


trait HasTemplates
{

}