"use strict"

jQuery(document).ready(function () {
    jQuery('body').addClass('elementor-editor-mode');
});