<?php

require LISTIVO_PATH . 'config/app.php';

require LISTIVO_PATH . 'config/demos.php';

require LISTIVO_PATH . 'config/settings.php';

require LISTIVO_PATH . 'config/dashboard.php';

require LISTIVO_PATH . 'config/providers.php';

require LISTIVO_PATH . 'config/admin_strings.php';

require LISTIVO_PATH . 'config/models.php';

require LISTIVO_PATH . 'config/strings.php';

require LISTIVO_PATH . 'config/slugs.php';

require LISTIVO_PATH . 'config/taxonomies.php';

require LISTIVO_PATH . 'config/posttypes.php';

require LISTIVO_PATH . 'config/fieldable.php';

require LISTIVO_PATH . 'config/templatable.php';

require LISTIVO_PATH . 'config/google_map_languages.php';

require LISTIVO_PATH . 'config/elementor_widgets.php';

require LISTIVO_PATH . 'config/image_sizes.php';

require LISTIVO_PATH . 'config/notifications.php';
